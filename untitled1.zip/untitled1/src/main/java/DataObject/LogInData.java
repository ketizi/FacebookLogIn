package DataObject;

public interface LogInData {
   public String

    incorrectEmailData = "test@test.ge",
    incorrectPasswordData = "123456",

    correctEmailData = "bord_t@yahoo.com";


}
